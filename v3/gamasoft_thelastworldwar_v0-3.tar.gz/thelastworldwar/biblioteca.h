#ifndef UNIDADE_H
#define UNIDADE_H

#include <sstream>
#include <string>

using namespace std;

extern string intToString(int x);


#endif
