#ifndef RANDOM_H
#define RANDOM_H

#include <cstdlib>
#include <ctime>

class Random
{
	public:
		Random();
		int gerarNumero(int);
};

#endif
