#include "biblioteca.h"

//util
string intToString(int x)
{
	stringstream ss;
	ss << x;
	return ss.str();
}

